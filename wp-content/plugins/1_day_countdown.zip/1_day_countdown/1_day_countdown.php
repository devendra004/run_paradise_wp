<?php
/**
* Plugin Name: 1 day Countdown
* Description: This plugin adds Counter for single day, and give you ability to put some text. you can modify color too.
* Version: 1.0.0
* Author: Rj.
* License: WEB2
*/

add_action('admin_menu','time_counter_rj');
function time_counter_rj() 
{
  add_menu_page('Time Counter Settings','Time Counter Settings','administrator', __FILE__,'time_counter_setting_page','' );
  add_action( 'admin_init','time_counter_setting' );
}
function time_counter_setting() 
{
  register_setting('Time-Counter-Settings','time_counter_top_heading');
  register_setting('Time-Counter-Settings','time_counter_bottom_heading1');
  register_setting('Time-Counter-Settings','time_counter_bottom_heading2');
  register_setting('Time-Counter-Settings','time_counter_post_id');
  register_setting('Time-Counter-Settings','time_counter_start_date');
  

  register_setting('Time-Counter-Settings','time_counter_container_color');
  register_setting('Time-Counter-Settings','time_counter_container_width');
  register_setting('Time-Counter-Settings','time_counter_container_height');

  register_setting('Time-Counter-Settings','time_counter_timer_color');
  register_setting('Time-Counter-Settings','time_counter_timer_font_size');

  register_setting('Time-Counter-Settings','time_counter_top_font_size');
  register_setting('Time-Counter-Settings','time_counter_bottom1_font_size');
  register_setting('Time-Counter-Settings','time_counter_bottom2_font_size');

  register_setting('Time-Counter-Settings','time_counter_top_text_color');
  register_setting('Time-Counter-Settings','time_counter_bottom1_text_color');
  register_setting('Time-Counter-Settings','time_counter_bottom2_text_color');
}
function time_counter_setting_page() 
{
  echo '<div class="wrap"><h2>Section Heading Settings</h2>';
  echo '<form method="post" action="options.php">';
  settings_fields('Time-Counter-Settings');
  do_settings_sections('Time-Counter-Settings');
  echo '<table class="form-table"><thead>';
  echo '<tr valign="top"><th scope="row"><h1>Disign Setting</h1></th></tr>';
  echo '<tr valign="top">
            
            <th scope="row">Container Color</th> 
            <td><input style="width:50%;" type="text" placeholder="#000" name="time_counter_container_color" value="'.esc_attr( get_option('time_counter_container_color') ).'" /></td>
            
            <th scope="row">Container Width (optional)</th>
            <td><input style="width:50%;" type="number" min="1" placeholder="300" name="time_counter_container_width" value="'.esc_attr( get_option('time_counter_container_width') ).'" /></td>
            <th scope="row">Container Height (optional)</th>
            <td><input style="width:50%;" type="number" min="1" placeholder="230" name="time_counter_container_height" value="'.esc_attr( get_option('time_counter_container_height') ).'" /></td>
            </tr>';
  echo '<tr valign="top">
            <th scope="row">Timer Color</th>
            <td><input style="width:50%;" type="text" placeholder="#fff" name="time_counter_timer_color" value="'.esc_attr( get_option('time_counter_timer_color') ).'" /></td>
            <th scope="row">Timer Font Size</th>
            <td><input style="width:50%;" type="number" min="1" placeholder="80" name="time_counter_timer_font_size" value="'.esc_attr( get_option('time_counter_timer_font_size') ).'" /></td>
            </tr>';
  echo '<tr valign="top">          
            <th scope="row">Top Font Size</th>
            <td><input style="width:50%;" type="number"min="1"  placeholder="40" name="time_counter_top_font_size" value="'.esc_attr( get_option('time_counter_top_font_size') ).'" /></td>
            <th scope="row">Bottom First Font Size</th>
            <td><input style="width:50%;" type="number" min="1" placeholder="23" name="time_counter_bottom1_font_size" value="'.esc_attr( get_option('time_counter_bottom1_font_size') ).'" /></td>
            <th scope="row">Bottom Second Font Size</th>
            <td><input style="width:50%;" type="number" min="1" placeholder="40" name="time_counter_bottom2_font_size" value="'.esc_attr( get_option('time_counter_bottom2_font_size') ).'" /></td></tr>';
  echo '<tr valign="top">
            <th scope="row">Top Text Color</th>
            <td><input style="width:50%;"  type="text" placeholder="#fff" name="time_counter_top_text_color" value="'.esc_attr( get_option('time_counter_top_text_color') ).'" /></td>
            <th scope="row">Bottom First Text Color</th>
            <td><input style="width:50%;" type="text" placeholder="#fff" name="time_counter_bottom1_text_color" value="'.esc_attr( get_option('time_counter_bottom1_text_color') ).'" /></td>
            <th scope="row">Bottom Second Text Color</th>
            <td><input style="width:50%;" type="text" placeholder="#fff" name="time_counter_bottom2_text_color" value="'.esc_attr( get_option('time_counter_bottom2_text_color') ).'" /></td>
        </tr></thead>';
        echo '<tbody><tr style="border-top:1px solid black;"></tr>';
  echo '<tr valign="top"><th scope="row"><h1>Field Setting</h1></th></tr>';
  echo '<tr valign="top">
            
            <th scope="row">Select Competition</th>
            <td colspan="2">
            <select style="width:100%;" name="time_counter_post_id" id="time_counter_post_id">';      
  global $query_string;
  $args = array('post_type' => 'post',
          'post_status' => array( 'publish','future'),
          'posts_per_page' => -1,
          'order' => 'DESC',
          );
  query_posts( $args );
  if ( have_posts() ) : 
    while ( have_posts() ) : the_post(); 
      $old_id = esc_attr( get_option('time_counter_post_id') );
      $new_id = get_the_ID();
      if($old_id == $new_id) { $selected="selected";} else { $selected = '';}
      echo '<option value="'.$new_id.'" '.$selected.'>'.get_the_title().'</option>';
    endwhile; 
  endif; 
  wp_reset_query();
  echo '</td>
        </tr>';
  echo '<tr valign="top">
            
            <th scope="row">Top Heading</th>
            <td colspan="2"><input style="width:100%;" type="text" id="time_counter_top_heading" name="time_counter_top_heading" value="'.esc_attr( get_option('time_counter_top_heading') ).'" /></td>
        </tr>';      
  echo '<tr valign="top">
            <th scope="row">Bottom Text :- First Line</th>
            <td colspan="2"><input type="text" style="width:100%;" name="time_counter_bottom_heading1" value="'.esc_attr( get_option('time_counter_bottom_heading1') ).'" /></td>
        </tr>';
  echo '<tr valign="top">
            <th scope="row">Bottom Text :- Second Line</th>
            <td colspan="2"><input type="text" style="width:100%;" name="time_counter_bottom_heading2" value="'.esc_attr( get_option('time_counter_bottom_heading2') ).'" /></td>
        </tr>';
  echo '<tr valign="top">
            <th scope="row">Counter Restart After (Days)</th>
            <td ><input type="number" style="width:100%;" name="time_counter_days" min="1" max="28" value="'.esc_attr( get_option('time_counter_days') ).'" /></td>
        </tr>';
  $start_date = esc_attr( get_option('time_counter_start_date') );
  if($start_date){} else { $start_date = date('m/d/Y');}
  echo '<tr valign="top">
            <th scope="row">Counter Start Date</th>
            <td ><input type="date" style="width:100%;" name="time_counter_start_date" value="'.esc_attr( get_option('time_counter_start_date') ).'" /></td>
        </tr>';
        //time_counter_start_date
  echo '<tr>
            <td>Shortcode to show Counter</td><td><input style="width:100%;" readonly value="[show_time_counter_rj]" /></td>
        </tr></tbody>';  
  echo'</table>';
  submit_button();
  echo '</form>';
  echo '</div>';
  ?>
  <script type="text/javascript">
  jQuery('#time_counter_post_id').change(function(){
    //var top_heading = jQuery('#time_counter_top_heading').val();
    //if(top_heading == '' || top_heading == NULL)
    //{
      var e = document.getElementById("time_counter_post_id");
      var strUser = e.options[e.selectedIndex].text;
      jQuery('#time_counter_top_heading').val(strUser);
    //}
  });
  </script>
  <?php
}
function show_time_counter_rj() 
{
  $counter_css = 'display:none; 
  background:'.esc_attr( get_option('time_counter_container_color')).'; 
  width:'.esc_attr( get_option('time_counter_container_width')).'px; 
  height:'.esc_attr( get_option('time_counter_container_height')).'px; ';

  $top_text_css = 'text-transform:none !important; 
  color:'.esc_attr( get_option('time_counter_top_text_color')).';
  font-size:'.esc_attr( get_option('time_counter_top_font_size')).'px;';

  $bottom1_css = 'text-transform:none !important; 
  color:'.esc_attr( get_option('time_counter_bottom1_text_color')).';
  font-size:'.esc_attr( get_option('time_counter_bottom1_font_size')).'px;';

  $bottom2_css = 'text-transform:none !important; 
  color:'.esc_attr( get_option('time_counter_bottom2_text_color')).';
  font-size:'.esc_attr( get_option('time_counter_bottom2_font_size')).'px;';

  $timer_css = 'font-size:'.esc_attr( get_option('time_counter_timer_font_size')).';
  color:'.esc_attr( get_option('time_counter_timer_color')).';';
  $t_size = esc_attr( get_option('time_counter_timer_font_size'));
  $t_size = (INTVAL($t_size)*20)/100;
  $timer_text_css = 'color:'.esc_attr( get_option('time_counter_timer_color')).'; 
  font-size:'.$t_size.'px;';

  $top_heading = esc_attr( get_option('time_counter_top_heading'));
  if(empty($top_heading) || $top_heading == '') { $top_heading = 'Click here';}
  $winpost_id = esc_attr( get_option('time_counter_post_id') );
  $winpost_link = get_permalink($winpost_id);



  echo '<div class="counter-box" style="'.$counter_css.'">';
  echo '<div class="top-text">';
  echo '<input type="hidden" id="time_counter_days" value="'.esc_attr( get_option('time_counter_days')).'" />';
  echo '<h1 style="'.$top_text_css.'" ><a style="'.$top_text_css.'" href="'.$winpost_link.'">'.$top_heading.'</a></h1>';
  echo '</div>';
  echo '<ul id="example">
            <li><span style="'.$timer_css.'" class="days">00</span><p style="'.$timer_text_css.'" class="days_text">D</p></li>
            <li class="seperator">:</li>
            <li ><span  style="'.$timer_css.'" class="hours">00</span><p style="'.$timer_text_css.'" class="hours_text">H</p></li>';
  echo '<li class="seperator"  style="'.$timer_css.'">:</li><li><span  style="'.$timer_css.'" class="minutes">00</span><p style="'.$timer_text_css.'" class="minutes_text">M</p></li>';
  echo '<li class="seperator"  style="'.$timer_css.'">:</li><li><span style="'.$timer_css.'" class="seconds">00</span><p style="'.$timer_text_css.'" class="seconds_text">S</p></li></ul>';
  echo '<div class="yesterday-win">';
  echo '<h3 style="'.$bottom1_css.'">'.esc_attr( get_option('time_counter_bottom_heading1')).'</h3>';
  echo '<h2 style="'.$bottom2_css.'">'.esc_attr( get_option('time_counter_bottom_heading2')).'</h2>';
  echo '</div>';
  echo '</div>';
  ?>
  <link type="text/css" href="<?php echo plugins_url( '1_day_countdown', FILE ); ?>/jquery.countdown.css" rel="stylesheet">
  <script type="text/javascript" src="<?php echo plugins_url( '1_day_countdown', FILE ); ?>/jquery.min.js"></script>
  <script src="<?php echo plugins_url( '1_day_countdown', FILE ); ?>/jquery.countdown.min.js " type="text/javascript"></script>
  <script type="text/javascript">
  var time_counter_days = $('#time_counter_days').val();
  if(time_counter_days == 0 || time_counter_days == undefined) { time_counter_days = 1;}
  var date = new Date();
  date.setDate(date.getDate() + 7);
  
  var currentYear = date.getFullYear();
  var currentMonth = date.getMonth() + 1;
  var currentDay = date.getDate();
  var cur_date_time = currentMonth+'/'+currentDay+'/'+currentYear+' 23:59:59';
  //alert(cur_date_time);
  $('#example').countdown({
   date: cur_date_time,
   offset: -1,
   day: 'D',
   days: 'D',
   minute: 'M',
   minutes: 'M',
   hour: 'H',
   hours: 'H',
   second: 'S',
   seconds: 'S'
  }, function () {
   //alert('Done!');
  });
  $('.counter-box').show();
 </script>
 
<?php
}
add_action( 'wp_footer', 'show_time_counter_rj' );
add_shortcode( 'show_time_counter_rj', 'show_time_counter_rj' );
?>
